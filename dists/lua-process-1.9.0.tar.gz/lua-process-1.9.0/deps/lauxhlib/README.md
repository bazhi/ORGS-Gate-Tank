lauxhlib
=========

lua auxiliary header library



